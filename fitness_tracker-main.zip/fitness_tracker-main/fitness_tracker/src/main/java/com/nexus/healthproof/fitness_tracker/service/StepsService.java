package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;
import com.nexus.healthproof.fitness_tracker.repository.StepsRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.nexus.healthproof.fitness_tracker.entity.Steps;
import com.nexus.healthproof.fitness_tracker.exception.StepsAlreadyExistsException;
import com.nexus.healthproof.fitness_tracker.exception.StepsNotFoundException;

@Service
@RequiredArgsConstructor
public class StepsService {

    private final StepsRepository stepsRepository;

    @Transactional
    public Steps create(User user, Steps steps) {
        if (stepsRepository.existsByUserAndDate(user, steps.getDate())) {
            throw new StepsAlreadyExistsException(
                    "Steps already recorded for date: " + steps.getDate()
            );
        }

        steps.setUser(user);
        return stepsRepository.save(steps);
    }

    public List<Steps> read(User user) {
        return stepsRepository.findByUser(user);
    }

    public Steps read(User user, LocalDate date) {
        return stepsRepository.findByUserAndDate(user, date)
                .orElseThrow(() ->
                        new StepsNotFoundException("Steps not found for date: " + date));
    }

    @Transactional
    public Steps update(User user, LocalDate date, Steps updates) {
        Steps existing = read(user, date);

        if (updates.getStepCount() != null)
            existing.setStepCount(updates.getStepCount());

        if (updates.getDailyGoal() != null)
            existing.setDailyGoal(updates.getDailyGoal());

        return stepsRepository.save(existing);
    }

    @Transactional
    public void delete(User user, LocalDate date) {
        stepsRepository.delete(read(user, date));
    }

    @Transactional
    public void deleteAll(User user) {
        stepsRepository.deleteAll(stepsRepository.findByUser(user));
    }
}

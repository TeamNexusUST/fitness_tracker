package com.nexus.healthproof.fitness_tracker.exception;


public class SleepNotFoundException extends RuntimeException{
    public SleepNotFoundException(String message){
        super(message);
    }
}

package com.nexus.healthproof.fitness_tracker.dto;

import lombok.Data;

import java.sql.Date;

@Data
public class UserRegisterRequest {

    private String username;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;
    private Date birthdate;
    private double heightInInches;
    private double activityLevel;
}

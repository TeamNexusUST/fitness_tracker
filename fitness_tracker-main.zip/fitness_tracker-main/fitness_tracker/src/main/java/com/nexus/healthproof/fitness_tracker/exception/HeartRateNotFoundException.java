package com.nexus.healthproof.fitness_tracker.exception;

public class HeartRateNotFoundException extends RuntimeException {
    public HeartRateNotFoundException(String message) {
        super(message);
    }
}

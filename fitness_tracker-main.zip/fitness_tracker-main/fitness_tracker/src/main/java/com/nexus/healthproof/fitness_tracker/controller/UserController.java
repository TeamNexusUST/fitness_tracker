package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.service.UserService;

import lombok.RequiredArgsConstructor;
import com.nexus.healthproof.fitness_tracker.dto.UserRegisterRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.nexus.healthproof.fitness_tracker.dto.UserRegisterRequest;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<User> register(
            @RequestBody UserRegisterRequest request
    ) {
        return ResponseEntity.ok(
                userService.registerUser(request)
        );
    }

    @GetMapping("/profile")
    public ResponseEntity<User> getMyProfile(Authentication authentication) {
        return userService.getUserByUsername(authentication.getName())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/updateProfile")
    public ResponseEntity<User> updateMyProfile(
            @RequestBody User updates,
            Authentication authentication) {

        User user = userService.getUserByUsername(authentication.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        return ResponseEntity.ok(
                userService.updateUser(user.getId(), updates)
        );
    }
}

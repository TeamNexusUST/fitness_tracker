package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.Steps;
import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.service.StepsService;
import com.nexus.healthproof.fitness_tracker.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/steps")
@RequiredArgsConstructor
public class StepsController {

    private final StepsService stepsService;
    private final UserService userService;

    private User getCurrentUser(Authentication authentication) {
        return userService.getUserByUsername(authentication.getName())
                .orElseThrow(() ->
                        new UserNotFoundException("User not found"));
    }

    @PostMapping
    public ResponseEntity<Steps> addSteps(
            @RequestBody Steps steps,
            Authentication authentication) {

        return ResponseEntity.ok(
                stepsService.create(getCurrentUser(authentication), steps)
        );
    }

    @GetMapping
    public ResponseEntity<List<Steps>> getAllSteps(Authentication authentication) {
        return ResponseEntity.ok(
                stepsService.read(getCurrentUser(authentication))
        );
    }

    @GetMapping("/{date}")
    public ResponseEntity<Steps> getStepsByDate(
            @PathVariable LocalDate date,
            Authentication authentication) {

        return ResponseEntity.ok(
                stepsService.read(getCurrentUser(authentication), date)
        );
    }

    @PutMapping("/{date}")
    public ResponseEntity<Steps> updateSteps(
            @PathVariable LocalDate date,
            @RequestBody Steps updates,
            Authentication authentication) {

        return ResponseEntity.ok(
                stepsService.update(getCurrentUser(authentication), date, updates)
        );
    }

    @DeleteMapping("/{date}")
    public ResponseEntity<Void> deleteSteps(
            @PathVariable LocalDate date,
            Authentication authentication) {

        stepsService.delete(getCurrentUser(authentication), date);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/all")
    public ResponseEntity<Void> deleteAllSteps(Authentication authentication) {
        stepsService.deleteAll(getCurrentUser(authentication));
        return ResponseEntity.noContent().build();
    }
}

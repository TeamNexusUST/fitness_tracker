package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.Activity;
import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.ActivityNotFoundException;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.ActivityRepository;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nexus.healthproof.fitness_tracker.exception.AccessDeniedException;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ActivityService {

    private final ActivityRepository activityRepository;
    private final UserRepository userRepository;

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + username));
    }

    @Transactional
    public Activity addActivity(String username, Activity activity) {
        User user = getUser(username);
        activity.setUser(user);
        return activityRepository.save(activity);
    }

    @Transactional(readOnly = true)
    public List<Activity> getActivities(String username) {
        User user = getUser(username);
        return activityRepository.findByUser(user);
    }

    @Transactional
    public Activity updateActivity(String username, UUID activityId, Activity updates) {
        User user = getUser(username);

        Activity activity = activityRepository.findById(activityId)
                .orElseThrow(() -> new ActivityNotFoundException("Activity not found"));

        if (!activity.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("You cannot update this activity");
        }

        if (updates.getName() != null) {
            activity.setName(updates.getName());
        }
        if (updates.getDuration() != null) {
            activity.setDuration(updates.getDuration());
        }
        if (updates.getDistance() != null) {
            activity.setDistance(updates.getDistance());
        }
        if (updates.getCaloriesBurned() != null) {
            activity.setCaloriesBurned(updates.getCaloriesBurned());
        }
        if (updates.getStartDate() != null) {
            activity.setStartDate(updates.getStartDate());
        }
        if (updates.getEndDate() != null) {
            activity.setEndDate(updates.getEndDate());
        }
        if (updates.getIntensityLevel() != null) {
            activity.setIntensityLevel(updates.getIntensityLevel());
        }

        return activityRepository.save(activity);
    }

    @Transactional
    public void deleteActivity(String username, UUID activityId) {
        User user = getUser(username);

        Activity activity = activityRepository.findById(activityId)
                .orElseThrow(() -> new ActivityNotFoundException("Activity not found"));

        if (!activity.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("You cannot delete this activity");
        }

        activityRepository.delete(activity);
    }

    @Transactional
    public void deleteAll(String username) {
        User user = getUser(username);
        activityRepository.deleteAll(activityRepository.findByUser(user));
    }
}

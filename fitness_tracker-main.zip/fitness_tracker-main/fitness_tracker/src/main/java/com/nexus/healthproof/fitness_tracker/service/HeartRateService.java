package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.HeartRate;
import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.AccessDeniedException;
import com.nexus.healthproof.fitness_tracker.exception.HeartRateNotFoundException;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.HeartRateRepository;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class HeartRateService {

    private final HeartRateRepository heartRateRepository;
    private final UserRepository userRepository;

    @Transactional
    public HeartRate createHeartRate(String username, HeartRate heartRate) {
        User user = fetchUser(username);
        heartRate.setUser(user);
        return heartRateRepository.save(heartRate);
    }

    public List<HeartRate> getAllHeartRates(String username) {
        User user = fetchUser(username);
        return heartRateRepository.findByUser(user);
    }

    public HeartRate getHeartRateById(String username, Long id) {
        User user = fetchUser(username);
        HeartRate heartRate = fetchHeartRate(id);

        if (!heartRate.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("Heart rate does not belong to user");
        }
        return heartRate;
    }

    @Transactional
    public void deleteHeartRate(String username, Long id) {
        User user = fetchUser(username);
        HeartRate heartRate = fetchHeartRate(id);

        if (!heartRate.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("Heart rate does not belong to user");
        }
        heartRateRepository.delete(heartRate);
    }

    @Transactional
    public void deleteAllHeartRates(String username) {
        User user = fetchUser(username);
        heartRateRepository.deleteAll(
                heartRateRepository.findByUser(user)
        );
    }


    private User fetchUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() ->
                        new UserNotFoundException("User not found: " + username));
    }

    private HeartRate fetchHeartRate(Long id) {
        return heartRateRepository.findById(id)
                .orElseThrow(() ->
                        new HeartRateNotFoundException("Heart rate not found with id: " + id));
    }
}

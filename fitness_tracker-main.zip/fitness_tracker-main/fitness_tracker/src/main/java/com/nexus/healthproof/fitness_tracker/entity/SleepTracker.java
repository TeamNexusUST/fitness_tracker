package com.nexus.healthproof.fitness_tracker.entity;

import jakarta.persistence.*;
import java.time.Duration;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;

@Entity
@Table(name = "sleep_tracker")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SleepTracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column(nullable = false)
    private LocalDateTime endTime;

    private long sleepDurationInMinutes;

    @Enumerated(EnumType.STRING)
    private SleepQuality sleepQuality;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonBackReference
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private User user;

    @PrePersist
    @PreUpdate
    public void calculateDurationAndQuality() {
        if (startTime != null && endTime != null) {
            long minutes = Duration.between(startTime, endTime).toMinutes();
            this.sleepDurationInMinutes = minutes;
            this.sleepQuality = SleepQuality.getSleepQuality(minutes);
        }
    }
}

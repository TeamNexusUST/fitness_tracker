package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.Goal;
import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.GoalNotFoundException;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.GoalRepository;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nexus.healthproof.fitness_tracker.exception.AccessDeniedException;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GoalService {

    private final GoalRepository goalRepository;
    private final UserRepository userRepository;

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() ->
                        new UserNotFoundException("User not found: " + username));
    }

    @Transactional
    public Goal addGoal(String username, Goal goal) {
        User user = getUser(username);
        goal.setUser(user);
        return goalRepository.save(goal);
    }

    public List<Goal> getGoalsByUsername(String username) {
        User user = getUser(username);
        return goalRepository.findByUser(user);
    }

    @Transactional
    public Goal updateGoal(String username, UUID goalId, Goal updates) {
        User user = getUser(username);

        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new GoalNotFoundException("Goal not found"));

        if (!goal.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("You cannot update this goal");
        }

        if (updates.getGoalType() != null)
            goal.setGoalType(updates.getGoalType());

        if (updates.getTargetValue() != null)
            goal.setTargetValue(updates.getTargetValue());

        if (updates.getStartDate() != null)
            goal.setStartDate(updates.getStartDate());

        if (updates.getEndDate() != null)
            goal.setEndDate(updates.getEndDate());

        return goalRepository.save(goal);
    }

    @Transactional
    public void deleteGoal(String username, UUID goalId) {
        User user = getUser(username);

        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new GoalNotFoundException("Goal not found"));

        if (!goal.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("You cannot delete this goal");
        }

        goalRepository.delete(goal);
    }

    @Transactional
    public void deleteAll(String username) {
        User user = getUser(username);
        goalRepository.deleteAll(goalRepository.findByUser(user));
    }
}

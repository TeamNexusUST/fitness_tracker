package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.entity.Weight;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.exception.WeightNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;
import com.nexus.healthproof.fitness_tracker.repository.WeightRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nexus.healthproof.fitness_tracker.exception.AccessDeniedException;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class WeightService {

    private final WeightRepository weightRepository;
    private final UserRepository userRepository;

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    @Transactional
    public Weight addWeight(String username, Weight weight) {
        User user = getUser(username);
        weight.setUser(user);
        return weightRepository.save(weight);
    }

    public List<Weight> getWeights(String username) {
        return weightRepository.findByUser(getUser(username));
    }

    @Transactional
    public Weight updateWeight(String username, UUID weightId, Weight updates) {
        Weight weight = weightRepository.findById(weightId)
                .orElseThrow(() -> new WeightNotFoundException("Weight not found"));

        if (!weight.getUser().getUsername().equals(username)) {
            throw new AccessDeniedException("You cannot update this weight entry");
        }

        if (updates.getDate() != null) weight.setDate(updates.getDate());
        if (updates.getPounds() != null) weight.setPounds(updates.getPounds());

        return weightRepository.save(weight);
    }

    @Transactional
    public void deleteWeight(String username, UUID weightId) {
        Weight weight = weightRepository.findById(weightId)
                .orElseThrow(() -> new WeightNotFoundException("Weight not found"));

        if (!weight.getUser().getUsername().equals(username)) {
            throw new AccessDeniedException("You cannot delete this weight entry");
        }

        weightRepository.delete(weight);
    }
}

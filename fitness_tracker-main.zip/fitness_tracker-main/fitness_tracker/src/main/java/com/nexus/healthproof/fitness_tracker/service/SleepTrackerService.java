package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.SleepTracker;
import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.SleepTrackRepository;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import com.nexus.healthproof.fitness_tracker.exception.AccessDeniedException;
import com.nexus.healthproof.fitness_tracker.exception.SleepNotFoundException;

@Service
@RequiredArgsConstructor
public class SleepTrackerService {

    private final SleepTrackRepository sleepTrackRepository;
    private final UserRepository userRepository;

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + username));
    }

    @Transactional
    public SleepTracker addSleep(String username, SleepTracker sleepTracker) {
        User user = getUser(username);
        sleepTracker.setUser(user);
        return sleepTrackRepository.save(sleepTracker);
    }

    public List<SleepTracker> getSleepByUser(String username) {
        User user = getUser(username);
        return sleepTrackRepository.findByUser(user);
    }

    @Transactional
    public SleepTracker updateSleep(String username, Long sleepId, SleepTracker updates) {
        User user = getUser(username);

        SleepTracker existing = sleepTrackRepository.findById(sleepId)
                .orElseThrow(() -> new SleepNotFoundException("Sleep record not found"));

        if (!existing.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("Forbidden");
        }

        if (updates.getStartTime() != null)
            existing.setStartTime(updates.getStartTime());

        if (updates.getEndTime() != null)
            existing.setEndTime(updates.getEndTime());

        return sleepTrackRepository.save(existing);
    }

    @Transactional
    public void deleteSleep(String username, Long sleepId) {
        User user = getUser(username);

        SleepTracker sleep = sleepTrackRepository.findById(sleepId)
                .orElseThrow(() -> new SleepNotFoundException("Sleep record not found"));

        if (!sleep.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("You cannot update this sleep record");
        }

        sleepTrackRepository.delete(sleep);
    }

    @Transactional
    public void deleteAll(String username) {
        User user = getUser(username);
        sleepTrackRepository.deleteAll(
                sleepTrackRepository.findByUser(user)
        );
    }
}

package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.Goal;
import com.nexus.healthproof.fitness_tracker.service.GoalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/goals")
@RequiredArgsConstructor
public class GoalController {

    private final GoalService goalService;

    // ADD goal (current user)
    @PostMapping
    public ResponseEntity<Goal> addGoal(
            @RequestBody Goal goal,
            Authentication authentication) {

        return ResponseEntity.ok(
                goalService.addGoal(authentication.getName(), goal)
        );
    }

    // GET my goals
    @GetMapping
    public ResponseEntity<List<Goal>> getMyGoals(Authentication authentication) {
        return ResponseEntity.ok(
                goalService.getGoalsByUsername(authentication.getName())
        );
    }

    // UPDATE goal
    @PatchMapping("/{goalId}")
    public ResponseEntity<Goal> updateGoal(
            @PathVariable UUID goalId,
            @RequestBody Goal updates,
            Authentication authentication) {

        return ResponseEntity.ok(
                goalService.updateGoal(authentication.getName(), goalId, updates)
        );
    }

    // DELETE goal
    @DeleteMapping("/{goalId}")
    public ResponseEntity<Void> deleteGoal(
            @PathVariable UUID goalId,
            Authentication authentication) {

        goalService.deleteGoal(authentication.getName(), goalId);
        return ResponseEntity.noContent().build();
    }
}

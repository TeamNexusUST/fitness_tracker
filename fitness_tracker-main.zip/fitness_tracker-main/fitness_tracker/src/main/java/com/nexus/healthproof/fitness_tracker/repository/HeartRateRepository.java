package com.nexus.healthproof.fitness_tracker.repository;

import com.nexus.healthproof.fitness_tracker.entity.HeartRate;
import com.nexus.healthproof.fitness_tracker.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HeartRateRepository extends JpaRepository<HeartRate, Long> {

    List<HeartRate> findByUser(User user);
}

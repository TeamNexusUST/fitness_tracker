package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.HeartRate;
import com.nexus.healthproof.fitness_tracker.service.HeartRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/heartrates")
@RequiredArgsConstructor
public class HeartRateController {

    private final HeartRateService heartRateService;

    @PostMapping
    public ResponseEntity<HeartRate> create(
            Authentication authentication,
            @RequestBody HeartRate heartRate) {

        return ResponseEntity.ok(
                heartRateService.createHeartRate(authentication.getName(), heartRate)
        );
    }

    @GetMapping
    public ResponseEntity<List<HeartRate>> getAll(Authentication authentication) {
        return ResponseEntity.ok(
                heartRateService.getAllHeartRates(authentication.getName())
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<HeartRate> getById(
            Authentication authentication,
            @PathVariable Long id) {

        return ResponseEntity.ok(
                heartRateService.getHeartRateById(authentication.getName(), id)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            Authentication authentication,
            @PathVariable Long id) {

        heartRateService.deleteHeartRate(authentication.getName(), id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/all")
    public ResponseEntity<Void> deleteAll(Authentication authentication) {
        heartRateService.deleteAllHeartRates(authentication.getName());
        return ResponseEntity.noContent().build();
    }
}

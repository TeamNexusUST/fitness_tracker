package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.Weight;
import com.nexus.healthproof.fitness_tracker.service.WeightService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;


import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/weights")
@RequiredArgsConstructor
public class WeightController {

    private final WeightService weightService;

    @PostMapping
    public ResponseEntity<Weight> add(
            @RequestBody Weight weight,
            Authentication authentication) {

        return ResponseEntity.ok(
                weightService.addWeight(authentication.getName(), weight)
        );
    }

    @GetMapping
    public ResponseEntity<List<Weight>> myWeights(Authentication authentication) {
        return ResponseEntity.ok(
                weightService.getWeights(authentication.getName())
        );
    }

    @PatchMapping("/{weightId}")
    public ResponseEntity<Weight> update(
            @PathVariable UUID weightId,
            @RequestBody Weight updates,
            Authentication authentication) {

        return ResponseEntity.ok(
                weightService.updateWeight(authentication.getName(), weightId, updates)
        );
    }

    @DeleteMapping("/{weightId}")
    public ResponseEntity<Void> delete(
            @PathVariable UUID weightId,
            Authentication authentication) {

        weightService.deleteWeight(authentication.getName(), weightId);
        return ResponseEntity.noContent().build();
    }
}


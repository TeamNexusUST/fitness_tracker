package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.Activity;
import com.nexus.healthproof.fitness_tracker.service.ActivityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/activities")
@RequiredArgsConstructor
public class ActivityController {

    private final ActivityService activityService;

    // CREATE activity (logged-in user)
    @PostMapping
    public ResponseEntity<Activity> createActivity(
            @RequestBody Activity activity,
            Authentication authentication) {

        Activity saved = activityService.addActivity(
                authentication.getName(), activity
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // GET all activities of logged-in user
    @GetMapping
    public ResponseEntity<List<Activity>> getMyActivities(
            Authentication authentication) {

        return ResponseEntity.ok(
                activityService.getActivities(authentication.getName())
        );
    }

    // UPDATE activity (only own activity)
    @PatchMapping("/{activityId}")
    public ResponseEntity<Activity> updateActivity(
            @PathVariable UUID activityId,
            @RequestBody Activity updates,
            Authentication authentication) {

        return ResponseEntity.ok(
                activityService.updateActivity(
                        authentication.getName(),
                        activityId,
                        updates
                )
        );
    }

    // DELETE single activity (only own)
    @DeleteMapping("/{activityId}")
    public ResponseEntity<Void> deleteActivity(
            @PathVariable UUID activityId,
            Authentication authentication) {

        activityService.deleteActivity(authentication.getName(), activityId);
        return ResponseEntity.noContent().build();
    }

    // DELETE all activities of logged-in user
    @DeleteMapping("/all")
    public ResponseEntity<Void> deleteAllActivities(
            Authentication authentication) {

        activityService.deleteAll(authentication.getName());
        return ResponseEntity.noContent().build();
    }
}

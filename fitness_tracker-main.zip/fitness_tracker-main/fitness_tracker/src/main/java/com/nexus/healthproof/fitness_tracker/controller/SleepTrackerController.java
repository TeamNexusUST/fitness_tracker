package com.nexus.healthproof.fitness_tracker.controller;

import com.nexus.healthproof.fitness_tracker.entity.SleepTracker;
import com.nexus.healthproof.fitness_tracker.service.SleepTrackerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sleep")
@RequiredArgsConstructor
public class SleepTrackerController {

    private final SleepTrackerService sleepTrackerService;

    // ADD sleep record
    @PostMapping
    public ResponseEntity<SleepTracker> addSleep(
            @RequestBody SleepTracker sleepTracker,
            Authentication authentication) {

        return ResponseEntity.ok(
                sleepTrackerService.addSleep(authentication.getName(), sleepTracker)
        );
    }

    // GET all sleep records
    @GetMapping
    public ResponseEntity<List<SleepTracker>> getSleep(Authentication authentication) {
        return ResponseEntity.ok(
                sleepTrackerService.getSleepByUser(authentication.getName())
        );
    }

    // UPDATE sleep record
    @PatchMapping("/{sleepId}")
    public ResponseEntity<SleepTracker> updateSleep(
            @PathVariable Long sleepId,
            @RequestBody SleepTracker updates,
            Authentication authentication) {

        return ResponseEntity.ok(
                sleepTrackerService.updateSleep(authentication.getName(), sleepId, updates)
        );
    }

    // DELETE sleep record
    @DeleteMapping("/{sleepId}")
    public ResponseEntity<Void> deleteSleep(
            @PathVariable Long sleepId,
            Authentication authentication) {

        sleepTrackerService.deleteSleep(authentication.getName(), sleepId);
        return ResponseEntity.noContent().build();
    }

    // DELETE all sleep records
    @DeleteMapping("/all")
    public ResponseEntity<Void> deleteAll(Authentication authentication) {
        sleepTrackerService.deleteAll(authentication.getName());
        return ResponseEntity.noContent().build();
    }
}

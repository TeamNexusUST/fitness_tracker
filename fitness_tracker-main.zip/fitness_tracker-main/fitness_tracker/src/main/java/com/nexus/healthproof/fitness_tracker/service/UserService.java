package com.nexus.healthproof.fitness_tracker.service;

import com.nexus.healthproof.fitness_tracker.entity.User;
import com.nexus.healthproof.fitness_tracker.exception.UserNotFoundException;
import com.nexus.healthproof.fitness_tracker.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import com.nexus.healthproof.fitness_tracker.dto.UserRegisterRequest;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.UUID;

import com.nexus.healthproof.fitness_tracker.dto.UserRegisterRequest;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public User registerUser(UserRegisterRequest request) {

        Timestamp now = new Timestamp(System.currentTimeMillis());

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .gender(request.getGender())
                .birthdate(request.getBirthdate())
                .heightInInches(request.getHeightInInches())
                .activityLevel(request.getActivityLevel())
                .createdTime(now)
                .lastUpdatedTime(now)
                .passwordHash(
                        passwordEncoder.encode(request.getPassword())
                )
                .build();

        return userRepository.save(user);
    }

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User getUserById(UUID id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));
    }

    @Transactional
    public User updateUser(UUID userId, User userUpdates) {
        User existingUser = getUserById(userId);

        if (userUpdates.getUsername() != null) {
            existingUser.setUsername(userUpdates.getUsername());
        }
        if (userUpdates.getGender() != null) {
            existingUser.setGender(userUpdates.getGender());
        }
        if (userUpdates.getBirthdate() != null) {
            existingUser.setBirthdate(userUpdates.getBirthdate());
        }
        if (userUpdates.getHeightInInches() != 0) {
            existingUser.setHeightInInches(userUpdates.getHeightInInches());
        }
        if (userUpdates.getActivityLevel() != 0) {
            existingUser.setActivityLevel(userUpdates.getActivityLevel());
        }
        if (userUpdates.getEmail() != null) {
            existingUser.setEmail(userUpdates.getEmail());
        }
        if (userUpdates.getPasswordHash() != null) {
            existingUser.setPasswordHash(passwordEncoder.encode(userUpdates.getPasswordHash()));
        }
        if (userUpdates.getFirstName() != null) {
            existingUser.setFirstName(userUpdates.getFirstName());
        }
        if (userUpdates.getLastName() != null) {
            existingUser.setLastName(userUpdates.getLastName());
        }

        existingUser.setLastUpdatedTime(new Timestamp(System.currentTimeMillis()));
        return userRepository.save(existingUser);
    }
}

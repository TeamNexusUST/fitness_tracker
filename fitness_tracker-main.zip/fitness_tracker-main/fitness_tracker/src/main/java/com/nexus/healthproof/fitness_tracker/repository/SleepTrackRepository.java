package com.nexus.healthproof.fitness_tracker.repository;

import com.nexus.healthproof.fitness_tracker.entity.SleepTracker;
import com.nexus.healthproof.fitness_tracker.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SleepTrackRepository extends JpaRepository<SleepTracker, Long> {
    List<SleepTracker> findByUser(User user);
}
